/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/

#include "agented.h"


RETSIGTYPE
stop_server(int a) {
    keep_running = 0;
}

int main (int argc, char **argv)
{
    agtConfiguracao *agtConf;
    agtConf = (agtConfiguracao*) malloc(sizeof(agtConfiguracao));

    //Busca as configura��es do coletor
    cfg_opt_t opts[] = {
                CFG_SIMPLE_INT ("agtTempoDeExecucaoDoLaco", &agtConf->agtTempoDeExecucaoDoLaco),
                CFG_SIMPLE_INT ("agtTempoDeCapturaParaProcesso", &agtConf->agtTempoDeCapturaProcesso),
                CFG_SIMPLE_INT ("agtTempoDeCapturaParaTemperatura", &agtConf->agtTempoDeCapturaTemperatura),
                CFG_SIMPLE_INT ("agtTempoDeCapturaParaParticao", &agtConf->agtTempoDeCapturaParticao),
                CFG_SIMPLE_STR ("agtProcTemperatura", &agtConf->agtProcTemperatura),
                CFG_SIMPLE_INT ("agtExibeNoticia", &agtConf->agtExibeNoticia),
                CFG_END()
                };
    utlLeConfiguracao(AGT_ARQUIVO_CONFIGURACAO, opts);

    UTL_EXIBE_NOTICIA = agtConf->agtExibeNoticia;



    int background = 0;
    int syslog = 0;

    snmp_enable_stderrlog();


    /* make us a agentx client. */
    netsnmp_ds_set_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_AGENT_ROLE, 1);

    /* run in background, if requested */
    if (background && netsnmp_daemonize(1, !syslog))
        exit(1);

    /* initialize tcpip, if necessary */
    SOCK_STARTUP;

    DEBUGMSG(("Before agent library init","\n"));
    /* initialize the agent library */
    init_agent("agented");


    /* mib code: nit_netSnmpIETFWGTable from init_netSnmpIETFWGTable.c */
    init_tccProcessTable();
    init_tccTemperatureTable();
    init_tccPartitionTable();

    /* example-demon will be used to read example-demon.conf files. */
    init_snmp("agented");

    /* In case we recevie a request to stop (kill -TERM or kill -INT) */
    keep_running = 1;
    signal(SIGTERM, stop_server);
    signal(SIGINT, stop_server);

    snmp_log(LOG_INFO,"agented is up and running.\n");

    pthread_t captura;
    pthread_create(&captura,NULL,(void *(*)(void *))&agtIniciaCaptura,(void *) agtConf);

    /* you're main loop here... */
    while(keep_running)
    {
        /* if you use select(), see snmp_select_info() in snmp_api(3) */
        /*     --- OR ---  */
        agent_check_and_process(1); /* 0 == don't block */
    }

    /* at shutdown time */
    snmp_shutdown("agented");
    SOCK_CLEANUP;

    free(agtConf);

    return 0;
}

void agtIniciaCaptura(void *conf)
{

    int tempoEmSegundos;
    utlTempoEmSegundos(&tempoEmSegundos);
    int executarProcesso    = tempoEmSegundos;
    int executarTemperatura = tempoEmSegundos;
    int executarParticao    = tempoEmSegundos;

    utlDebug("Iniciando monitora��o pelo agente.", UTL_NOTICIA);
    struct agtProcesso *ok;

    agtConfiguracao *agtConf;
    agtConf = conf;

    utlObtemTempoDecorrido();
    agtAtribuiListaDeProcessos();
    int x=1;

    while (1)
    {
        //Tempo de espera para execu��o do la�o
        sleep(agtConf->agtTempoDeExecucaoDoLaco);

        char dataHora[40];
        utlDataHoraAtual(dataHora);

        if (utlExecutarColeta(executarProcesso))
        {
            //Atribui o tempo para a pr�xima leitura
            executarProcesso += agtConf->agtTempoDeCapturaProcesso;

            float tempoDeEspera = utlObtemTempoDecorrido();
            float percentualTotalCPU = 0;
            agtAtribuiListaDeProcessos();


            //Extrai processos
            agtPonteiroParaInicio();
            do
            {
                ok = agtPegaProcessoAtual();
                float percentualCPU     = (ok->jiffies / (HZ * tempoDeEspera)) * 100;
                float percentualMemoria = (float) (ok->resident / (float) utlTotalMemKB()) * 100;
                percentualTotalCPU += percentualCPU;
                if (ok->jiffies > 0)
                {
                    char buf1[30];
                    char buf2[30];

                    sprintf(buf1, "%f", percentualCPU);
                    sprintf(buf2, "%f", percentualMemoria);
                    agtAdicionaProcessoNaMIB(ok->pid, dataHora, ok->comm, ok->usuario, buf1, buf2);
                    x++;
                }
            } while (agtProximoProcesso());
        }

        //Extrai temperatura
        if (agtConf->agtProcTemperatura != NULL)
        {
            if (utlExecutarColeta(executarTemperatura))
            {
                //Atribui o tempo para a pr�xima leitura
                executarTemperatura += agtConf->agtTempoDeCapturaTemperatura;

                int temperatura;
                utlLeTemperatura(&temperatura, agtConf->agtProcTemperatura);
                agtAdicionaTemperaturaNaMIB(dataHora, temperatura);
            }
        }

        //Extrai dados das partic�es do disco
        if (utlExecutarColeta(executarParticao))
        {
            //Atribui o tempo para a pr�xima leitura
            executarParticao += agtConf->agtTempoDeCapturaParticao;

            agtListaDeParticoes *agtLParticoes, *agtLParticoesAux;
            agtLParticoes = (agtListaDeParticoes*) malloc(sizeof(agtListaDeParticoes));

            agtLeParticoes(agtLParticoes);
            for (agtLParticoesAux = agtLParticoes; agtLParticoesAux != (agtListaDeParticoes*) NULL;  agtLParticoesAux = agtLParticoesAux->proximo)
            {
                char buf1[30];
                char buf2[30];
                sprintf(buf1, "%f", agtLParticoesAux->totalEmKb);
                sprintf(buf2, "%f", agtLParticoesAux->usadoEmKb);

                agtAdicionaParticoesNaMIB(dataHora, agtLParticoesAux->nome, agtLParticoesAux->pontoDeMontagem, buf1, buf2);
            }
            agtRemoverListaDeParticoes(agtLParticoes);
        }
    }
}
