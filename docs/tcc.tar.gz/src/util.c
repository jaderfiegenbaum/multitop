/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/


#ifdef UTLCMPAGENTE
static float utlObtemTempoDecorrido(void)
{
   struct timeval t;
   static struct timeval oldtime;
   struct timezone timez;
   float elapsed_time;

   gettimeofday(&t, &timez);
   elapsed_time = (t.tv_sec - oldtime.tv_sec)
      + (float) (t.tv_usec - oldtime.tv_usec) / 1000000.0;
   oldtime.tv_sec  = t.tv_sec;
   oldtime.tv_usec = t.tv_usec;

   return elapsed_time;
}

static unsigned long utlTotalMemKB(void)
{
   int len;
   FILE *meminfo;
   char buffer[2048], *p;
   unsigned long memtotal;

   meminfo = fopen("/proc/meminfo", "r");
   if(!meminfo)
      return 0;

   len = fread(buffer, sizeof(char), sizeof(buffer)-1, meminfo);
   buffer[len] = '\0';
   fclose(meminfo);

   p = (char*) strstr( buffer, "MemTotal:" );
   if (!p)
      return 0;

   sscanf(p, "MemTotal: %lu ", &memtotal);
   return memtotal;
}
#endif

void utlLeTemperatura(int *temperatura, char *procTemp)
{
    FILE* status;

    status = fopen(procTemp, "r");
    if (status)
    {
        fscanf(status, "temperature:%d", temperatura);
    }
    fclose(status);
}

void utlUsuarioDoProcesso(int pid, char *nome)
{
    struct stat sb;
    struct passwd* dadosUsuario;
    int rc, uid;

    char buffer[32];
    sprintf(buffer, "/%s/%d", PROC_DIR, pid);
    rc = stat(buffer, &sb);
    uid = sb.st_uid;

    dadosUsuario = getpwuid(uid);
    if (dadosUsuario)
    {
        sprintf(nome, "%s", dadosUsuario->pw_name);
    }
    else
    {
        sprintf(nome, "%d", uid);
    }
}

void utlDataHoraAtual(char *dataHora)
{
    struct timeval tv;
    struct tm* ptm;
    char time[40];


    gettimeofday(&tv, NULL);
    ptm = localtime(&tv.tv_sec);
    strftime(time, sizeof(time), "%Y%m%d %H%M%S", ptm);
    sprintf(dataHora, "%s", time);
}

void utlTempoEmSegundos(int *segundos)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);

    *segundos = tv.tv_sec;
}

bool utlExecutarColeta(int tempoEmSegundos)
{
    int tempoAtualEmSegundos;
    utlTempoEmSegundos(&tempoAtualEmSegundos);

    if (tempoEmSegundos <= tempoAtualEmSegundos)
    {
        return true;
    }

    return false;
}

void utlDebug(char *msg, int tipoDeErro, ...)
{
    if (UTL_EXIBE_NOTICIA == 0 && tipoDeErro == UTL_NOTICIA)
    {
        return;
    }

    switch (tipoDeErro)
    {
        case UTL_NOTICIA:    printf("NOT�CIA: "); break;
        case UTL_CUIDADO:    printf("CUIDADE: "); break;
        case UTL_ERRO_FATAL: printf("ERRO FATAL: "); break;
    }

    va_list argv;
    va_start(argv, tipoDeErro);
    while (*msg)
    {
        char caract = *msg;

        if (caract != '%')
        {
            printf("%c", caract);
            msg++;
            continue;
        }
        msg++;
        switch (*msg)
        {
            case 'c': printf("%c", va_arg(argv, int)); break;
            case 's': printf("%s", va_arg(argv, char*)); break;
            case 'd': printf("%d", va_arg(argv, int)); break;
            default: printf("%c", caract);
        }
        msg++;
    }
    printf("\n");
    va_end(argv);
    if (tipoDeErro == UTL_ERRO_FATAL)
    {
        exit(1);
    }
}

void utlLeConfiguracao(char *nomeDoArquivo, cfg_opt_t opts[])
{
    utlDebug("Lendo arquivo de configura��o '%s'", UTL_NOTICIA, nomeDoArquivo);

    int ret;

    cfg_t *cfg;
    cfg = cfg_init (opts, 0);
    ret = cfg_parse (cfg, nomeDoArquivo);

    if(ret == CFG_FILE_ERROR)
    {
        utlDebug("N�o foi poss�vel ler o arquivo '%s'.", UTL_ERRO_FATAL, nomeDoArquivo);
    }
    else if(ret == CFG_PARSE_ERROR)
    {
        utlDebug("Erro de sintaxe no arquivo '%s'.", UTL_ERRO_FATAL, nomeDoArquivo);
    }
    cfg_free(cfg);
}

void utlLeListaConfiguracao(char *nomeDoArquivo, cfg_opt_t opts[], char *nomeDaLista, utlListaConfiguracao *utlLC)
{
    utlDebug("Lendo arquivo de configura��o '%s'", UTL_NOTICIA, nomeDoArquivo);

    int ret, i;

    utlListaConfiguracao *novo;
    cfg_t *cfg;
    cfg = cfg_init (opts, 0);
    ret = cfg_parse (cfg, nomeDoArquivo);

    if(ret == CFG_FILE_ERROR)
    {
        utlDebug("N�o foi poss�vel ler o arquivo '%s'.", UTL_ERRO_FATAL, nomeDoArquivo);
    }
    else if(ret == CFG_PARSE_ERROR)
    {
        utlDebug("Erro de sintaxe no arquivo '%s'.", UTL_ERRO_FATAL, nomeDoArquivo);
    }

    for(i = 0; i < cfg_size(cfg, nomeDaLista); i++)
    {
        if ( i > 0 )
        {
            novo = (utlListaConfiguracao*) malloc(sizeof(utlListaConfiguracao));
            utlLC->proximo = novo;
            utlLC = utlLC->proximo;
        }
        strcpy(utlLC->valor, cfg_getnstr(cfg, nomeDaLista, i));
        utlLC->proximo = (utlListaConfiguracao*) NULL;
    }
    printf("\n");

    cfg_free(cfg);
}

void utlRemoveListaConfiguracao(utlListaConfiguracao *utlLC)
{
    utlListaConfiguracao *auxiliar;
    utlDebug("Remove lista de configura��o", UTL_NOTICIA);
    while (utlLC != (utlListaConfiguracao*) NULL)
    {
        auxiliar = utlLC;
        utlLC = utlLC->proximo;
        free(auxiliar);
    }
}

void utlCortaTexto(char *parte, char *texto, char *separador, int posicao)
{
    int parteDoTexto = 0;
    int x = 0;
    char *inicioSeparador = separador;

    while (*texto)
    {
        if (*texto == *separador)
        {
            separador++;
            if (!*separador)
            {
                if (parteDoTexto == posicao)
                {
                    break;
                }
                parteDoTexto++;
                x = 0;
                separador = inicioSeparador;
            }
        }
        else
        {
            parte[x] = *texto;
            x++;
        }
        texto++;
    }
    if (parteDoTexto < posicao)
    {
        x = 0;
    }
    parte[x] = '\0';
}
