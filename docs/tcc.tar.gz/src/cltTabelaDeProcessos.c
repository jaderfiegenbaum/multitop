/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/


bool cltBuscaTabelaDeProcessos(cltTabelaDeProcessos *cltTP, struct snmp_session *ss)
{
    int x = 1, acabou = 0, maisLinhas = 0;
    char buf[50];
    char resultadoTmp[50];
    while(!acabou)
    {
        sprintf(buf, "TCC-MIB::pIDDaLinha.%d", x);
        if (!snmpGet(ss, buf, &cltTP->IDDaLinha, &maisLinhas))
        {
            cltTP->proximo = (cltTabelaDeProcessos*) NULL;
            cltTP = (cltTabelaDeProcessos*) NULL;
            return false;
        }

        if (maisLinhas == 0)
        {
            if (x == 1)
            {
                cltTP->proximo = (cltTabelaDeProcessos*) NULL;
                return false;
            }
            acabou = 1;
            break;
        }

        if (x > 1)
        {
            cltTP->proximo = (cltTabelaDeProcessos*) malloc(sizeof(cltTabelaDeProcessos));
            cltTP = cltTP->proximo;
        }
        sprintf(buf, "TCC-MIB::pID.%d", x);
        snmpGet(ss, buf, &cltTP->ID, &maisLinhas);

        sprintf(buf, "TCC-MIB::pDataHoraDaColeta.%d", x);
        snmpGet(ss, buf, &cltTP->dataHoraInicial, &maisLinhas);
        strcpy(cltTP->dataHoraFinal, cltTP->dataHoraInicial);

        sprintf(buf, "TCC-MIB::pNome.%d", x);
        snmpGet(ss, buf, &cltTP->nome, &maisLinhas);

        sprintf(buf, "TCC-MIB::pUsuario.%d", x);
        snmpGet(ss, buf, &cltTP->usuario, &maisLinhas);

        sprintf(buf, "TCC-MIB::pUtilizacaoDaCPU.%d", x);
        snmpGet(ss, buf, &resultadoTmp, &maisLinhas);
        cltTP->utilizacaoDaCPU = atof(resultadoTmp);

        sprintf(buf, "TCC-MIB::pUtilizacaoDaMemoria.%d", x);
        snmpGet(ss, buf, &resultadoTmp, &maisLinhas);
        cltTP->utilizacaoDaMemoria = atof(resultadoTmp);

        cltTP->quantidadeDeAgrupamentos = 1;

        cltTP->proximo = (cltTabelaDeProcessos*) NULL;
        x++;
    }

    utlDebug("%d processo(s) adicinado(s) na lista.", UTL_NOTICIA, x-1);
    return true;
}

void cltImprimeTabelaDeProcessos(cltTabelaDeProcessos *cltTP, char *cltNomeDoHost)
{
    cltTabelaDeProcessos *auxiliar;
    printf("Tabela de processos:\n");
    for (auxiliar = cltTP; auxiliar != (cltTabelaDeProcessos*) NULL; auxiliar = auxiliar->proximo)
    {
        printf("%s %d %s %s %s %s %f %f\n", cltNomeDoHost,
                                            auxiliar->ID,
                                            auxiliar->dataHoraInicial,
                                            auxiliar->dataHoraFinal,
                                            auxiliar->nome,
                                            auxiliar->usuario,
                                            auxiliar->utilizacaoDaCPU,
                                            auxiliar->utilizacaoDaMemoria);
    }
}

void cltNovaEstruturaAgrupada(cltTabelaDeProcessos *cltTP, cltTabelaDeProcessos *cltNovaTP)
{
    cltTabelaDeProcessos *auxiliar;
    cltTabelaDeProcessos *auxiliarNova;
    cltTabelaDeProcessos *inicioNova;
    int x = 0;
    int quantidadeDeTempos = 0; //Utilizado para fazer a m�dia da utiliza��o da CPU
    char dataHoraAuxiliar[UTL_TAM_MAX_P] = "";
    char dataHoraInicial[UTL_TAM_MAX_P] = "";
    char dataHoraFinal[UTL_TAM_MAX_P] = "";

    inicioNova = cltNovaTP;

    strcpy(dataHoraInicial, cltTP->dataHoraInicial);
    for (auxiliar = cltTP; auxiliar != (cltTabelaDeProcessos*) NULL; auxiliar = auxiliar->proximo)
    {
        int insereNova = 1;

        if (strcmp(auxiliar->dataHoraInicial, dataHoraAuxiliar) != 0)
        {
            strcpy(dataHoraAuxiliar, auxiliar->dataHoraInicial);
            quantidadeDeTempos++;
        }

        if (x > 0)
        {
            //Percore a nova estrutura para somar os valores de processos iguais
            for (auxiliarNova = inicioNova; auxiliarNova != (cltTabelaDeProcessos*) NULL; auxiliarNova = auxiliarNova->proximo)
            {
                //printf("aa(%d): %d = %d\n", x, auxiliarNova->ID, auxiliar->ID);
                if (auxiliarNova->ID == auxiliar->ID && strcmp(auxiliarNova->nome, auxiliar->nome) == 0 && strcmp(auxiliarNova->usuario, auxiliar->usuario) == 0)
                {
                    //printf("Soma(%d): (%d | %d)- %f+%f \n", x, auxiliarNova->ID, auxiliar->ID, auxiliarNova->utilizacaoDaCPU, auxiliar->utilizacaoDaCPU);
                    auxiliarNova->utilizacaoDaCPU += auxiliar->utilizacaoDaCPU;
                    auxiliarNova->utilizacaoDaMemoria += auxiliar->utilizacaoDaMemoria;
                    auxiliarNova->quantidadeDeAgrupamentos++;
                    insereNova = 0;
                }
            }
        }

        if (insereNova)
        {
            if (x > 0 )
            {
                cltNovaTP->proximo = (cltTabelaDeProcessos*) malloc(sizeof(cltTabelaDeProcessos));
                cltNovaTP = cltNovaTP->proximo;
            }
            //Adiciona novo item na lista
            cltNovaTP->ID = auxiliar->ID;
            //strcpy(cltNovaTP->dataHoraInicial, dataHoraInicial);
            //strcpy(cltNovaTP->dataHoraFinal, auxiliar->dataHoraFinal);
            strcpy(cltNovaTP->nome, auxiliar->nome);
            strcpy(cltNovaTP->usuario, auxiliar->usuario);
            cltNovaTP->utilizacaoDaCPU = auxiliar->utilizacaoDaCPU;
            cltNovaTP->utilizacaoDaMemoria = auxiliar->utilizacaoDaMemoria;
            cltNovaTP->quantidadeDeAgrupamentos = cltTP->quantidadeDeAgrupamentos;

            cltNovaTP->proximo = (cltTabelaDeProcessos*) NULL;
        }
        strcpy(dataHoraFinal, auxiliar->dataHoraFinal);
        x++;
    }

    //Percore a nova estrutura para fazer a m�dia dos valores
    for (auxiliarNova = inicioNova; auxiliarNova != (cltTabelaDeProcessos*) NULL; auxiliarNova = auxiliarNova->proximo)
    {
        //printf("M�dia: (%d)- %f/%d \n", auxiliarNova->ID, auxiliarNova->utilizacaoDaMemoria, auxiliarNova->quantidadeDeAgrupamentos);
        auxiliarNova->utilizacaoDaMemoria /= auxiliarNova->quantidadeDeAgrupamentos;

        //printf("M�dia CPU: (%d)- %f/%d \n", auxiliarNova->ID, auxiliarNova->utilizacaoDaCPU, quantidadeDeTempos);
        auxiliarNova->utilizacaoDaCPU /= quantidadeDeTempos;

        //Adiciona a data e hora inicial do agrupamento
        strcpy(auxiliarNova->dataHoraInicial, dataHoraInicial);
        //Adiciona a data e hora final do agrupamento
        strcpy(auxiliarNova->dataHoraFinal, dataHoraFinal);
    }
}

void cltGravarTabelaDeProcessos(cltTabelaDeProcessos *cltTP, cltConfiguracao * cltConf)
{
    cltTabelaDeProcessos *auxiliar;
    char bufSql[UTL_TAM_MAX_G];
    int quantidade = 0;

    PGconn *con = NULL;
    con = bdConectar(cltConf);
    for (auxiliar = cltTP; auxiliar != (cltTabelaDeProcessos*) NULL;  auxiliar = auxiliar->proximo)
    {
        sprintf(bufSql, "INSERT INTO processos (nomeDoHost, pid,  datahorainicial, datahorafinal, nome, usuario, utilizacaoDaCPU, utilizacaoDaMemoria)"
                                       " VALUES ('%s', %d,  '%s', '%s', '%s', '%s', %f, %f);",
                                                cltConf->cltNomeDoHost,
                                                auxiliar->ID,
                                                auxiliar->dataHoraInicial,
                                                auxiliar->dataHoraFinal,
                                                auxiliar->nome,
                                                auxiliar->usuario,
                                                auxiliar->utilizacaoDaCPU,
                                                auxiliar->utilizacaoDaMemoria);

        bdExecutar(con, bufSql);
        quantidade++;
    }
    bdFechar(con);

    utlDebug("%d processo(s) gravado(s) na base.", UTL_NOTICIA, quantidade);
}

void cltRemoverTabelaDeProcessos(cltTabelaDeProcessos *cltTP)
{
    cltTabelaDeProcessos *auxiliar = (cltTabelaDeProcessos*) NULL;
    cltTabelaDeProcessos *anterior = (cltTabelaDeProcessos*) NULL;
    int quantidade = 0;
    for (auxiliar = cltTP; auxiliar != (cltTabelaDeProcessos*) NULL;  )
    {
        anterior = auxiliar;
        auxiliar = auxiliar->proximo;
        anterior->proximo = (cltTabelaDeProcessos*) NULL;
        free(anterior);
        quantidade++;
    }
    //free(auxiliar);

    utlDebug("%d processo(s) removido(s) da lista.", UTL_NOTICIA, quantidade);
}
