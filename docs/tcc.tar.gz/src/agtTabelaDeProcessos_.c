/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/

int exibeMemoria = 1;

int agtTabelaDeProcessosHandler( netsnmp_mib_handler *handler, netsnmp_handler_registration *reginfo, netsnmp_agent_request_info *reqinfo, netsnmp_request_info *requests)
{
    if (reqinfo->mode == MODE_GET)
    {
        char buf[40];
        snprint_objid(buf, 40-1, requests->requestvb->name,requests->requestvb->name_length);

        char nomeDaColuna[40];
        char numeroDaLinha[40];
        utlCortaTexto(nomeDaColuna, buf, ".", 0);
        utlCortaTexto(numeroDaLinha, buf, ".", 1);


        if (!strcmp("TCC-MIB::pUtilizacaoDaMemoria", nomeDaColuna))
        {
            netsnmp_table_row *row;
            row=netsnmp_extract_table_row (requests);

            netsnmp_table_dataset_remove_and_delete_row (table_set, row);
            if (atoi(numeroDaLinha) == IDDaLinha)
            {
                IDDaLinha = 0;
            }
        }
    }

    return SNMP_ERR_NOERROR;
}

void agtAdicionaProcessoNaMIB(int pid, char *dataHoraDaCaptura, char *comm, char *usuario, char *percentualCPU, char *percentualMemoria)
{
    netsnmp_table_row *row;
    IDDaLinha++;

    row = netsnmp_create_table_data_row();

    netsnmp_table_row_add_index(row, ASN_INTEGER, &IDDaLinha,
                                sizeof(IDDaLinha));
    netsnmp_set_row_column(row, COLUMN_PIDDALINHA, ASN_INTEGER,
                        &IDDaLinha, sizeof(IDDaLinha));
    netsnmp_mark_row_column_writable(row, COLUMN_PIDDALINHA, 1);


    netsnmp_set_row_column(row, COLUMN_PID, ASN_INTEGER,
                        &pid, sizeof(pid));
    netsnmp_mark_row_column_writable(row, COLUMN_PID, 1);

    netsnmp_set_row_column(row, COLUMN_PDATAHORADACOLETA, ASN_OCTET_STR,
                            dataHoraDaCaptura, strlen(dataHoraDaCaptura));
    netsnmp_mark_row_column_writable(row, COLUMN_PDATAHORADACOLETA, 1);

    netsnmp_set_row_column(row, COLUMN_PNOME, ASN_OCTET_STR,
                            comm, strlen(comm));
    netsnmp_mark_row_column_writable(row, COLUMN_PNOME, 1);

    netsnmp_set_row_column(row, COLUMN_PUSUARIO, ASN_OCTET_STR, usuario,
                        strlen(usuario));
    netsnmp_mark_row_column_writable(row, COLUMN_PUSUARIO, 1);

    netsnmp_set_row_column(row, COLUMN_PUTILIZACAODACPU, ASN_OCTET_STR, percentualCPU,
                        strlen(percentualCPU));
    netsnmp_mark_row_column_writable(row, COLUMN_PUTILIZACAODACPU, 1);

    netsnmp_set_row_column(row, COLUMN_PUTILIZACAODAMEMORIA, ASN_OCTET_STR, percentualMemoria,
                        strlen(percentualMemoria));
    netsnmp_mark_row_column_writable(row, COLUMN_PUTILIZACAODAMEMORIA, 1);

    netsnmp_table_dataset_add_row(table_set, row);

}
