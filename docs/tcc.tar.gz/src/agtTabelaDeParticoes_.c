
/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/

int agtTabelaDeParticoesHandler( netsnmp_mib_handler *handler, netsnmp_handler_registration *reginfo, netsnmp_agent_request_info *reqinfo, netsnmp_request_info *requests)
{
    if (reqinfo->mode == MODE_GET)
    {
        char buf[40];
        snprint_objid(buf, 40-1, requests->requestvb->name,requests->requestvb->name_length);

        char nomeDaColuna[40];
        char numeroDaLinha[40];
        utlCortaTexto(nomeDaColuna, buf, ".", 0);
        utlCortaTexto(numeroDaLinha, buf, ".", 1);


        if (!strcmp("TCC-MIB::aUsadoEmKb", nomeDaColuna))
        {
            netsnmp_table_row *row;
            row=netsnmp_extract_table_row (requests);

            netsnmp_table_dataset_remove_and_delete_row (a_table_set, row);
            if (atoi(numeroDaLinha) == aIDDaLinha)
            {
                aIDDaLinha = 0;
            }
        }
    }

    return SNMP_ERR_NOERROR;
}

void agtAdicionaParticoesNaMIB(char *dataHoraDaCaptura, char *nome, char *pontoDeMontagem, char *totalEmKb, char *usadoEmKb)
{
    netsnmp_table_row *row;
    aIDDaLinha++;

    row = netsnmp_create_table_data_row();

    netsnmp_table_row_add_index(row, ASN_INTEGER, &aIDDaLinha,
                                sizeof(aIDDaLinha));
    netsnmp_set_row_column(row, COLUMN_AIDDALINHA, ASN_INTEGER,
                        &aIDDaLinha, sizeof(aIDDaLinha));
    netsnmp_mark_row_column_writable(row, COLUMN_AIDDALINHA, 1);

    netsnmp_set_row_column(row, COLUMN_ADATAHORADACOLETA, ASN_OCTET_STR,
                            dataHoraDaCaptura, strlen(dataHoraDaCaptura));
    netsnmp_mark_row_column_writable(row, COLUMN_ADATAHORADACOLETA, 1);

    netsnmp_set_row_column(row, COLUMN_ANOME, ASN_OCTET_STR,
                            nome, strlen(nome));
    netsnmp_mark_row_column_writable(row, COLUMN_ANOME, 1);

    netsnmp_set_row_column(row, COLUMN_APONTODEMONTAGEM, ASN_OCTET_STR,
                            pontoDeMontagem, strlen(pontoDeMontagem));
    netsnmp_mark_row_column_writable(row, COLUMN_APONTODEMONTAGEM, 1);

    netsnmp_set_row_column(row, COLUMN_ATOTALEMKB, ASN_OCTET_STR,
                            totalEmKb, strlen(totalEmKb));
    netsnmp_mark_row_column_writable(row, COLUMN_ATOTALEMKB, 1);

    netsnmp_set_row_column(row, COLUMN_AUSADOEMKB, ASN_OCTET_STR,
                            usadoEmKb, strlen(usadoEmKb));
    netsnmp_mark_row_column_writable(row, COLUMN_AUSADOEMKB, 1);

    netsnmp_table_dataset_add_row(a_table_set, row);

}
