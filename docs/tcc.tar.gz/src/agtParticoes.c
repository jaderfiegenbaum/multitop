
/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/

bool agtLeParticoes(agtListaDeParticoes *agtLParticoes)
{
    struct mntent *mnt;
    char *table = MOUNTED;
    FILE *fp;
    int x = 1;

    fp = setmntent (table, "r");
    if (fp == NULL)
    {
      return false;
    }

    while ((mnt = getmntent(fp)))
    {
        struct statfs fsd;

        if (statfs(mnt->mnt_dir, &fsd) < 0)
        {
              return false;
        }
        if (x > 1)
        {
            agtLParticoes->proximo = (agtListaDeParticoes*) malloc(sizeof(agtListaDeParticoes));
            agtLParticoes = agtLParticoes->proximo;
        }

        agtLParticoes->proximo = (agtListaDeParticoes*) NULL;
        strcpy(agtLParticoes->nome, mnt->mnt_fsname);
        strcpy(agtLParticoes->pontoDeMontagem, mnt->mnt_dir);
        agtLParticoes->totalEmKb = (float)fsd.f_blocks * (fsd.f_bsize / 1024.0);
        agtLParticoes->usadoEmKb = (float)(fsd.f_blocks - fsd.f_bfree)  * (fsd.f_bsize / 1024.0);

        x++;
    }
    return true;
}

void agtRemoverListaDeParticoes(agtListaDeParticoes *agtLParticoes)
{
    agtListaDeParticoes *auxiliar = (agtListaDeParticoes*) NULL;
    agtListaDeParticoes *anterior = (agtListaDeParticoes*) NULL;
    int quantidade = 0;

    for (auxiliar = agtLParticoes; auxiliar != (agtListaDeParticoes*) NULL;  )
    {
        anterior = auxiliar;
        auxiliar = auxiliar->proximo;
        anterior->proximo = (agtListaDeParticoes*) NULL;
        free(anterior);
        quantidade++;
    }
    //free(auxiliar);

    utlDebug("%d particoes removidas da lista.", UTL_NOTICIA, quantidade);
}
