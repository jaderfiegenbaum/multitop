/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/

#include "coletord.h"
#include <libpq-fe.h>

int main(int argc, char **argv)
{
    cltConfiguracao *cltConf;
    cltConf = (cltConfiguracao*) malloc(sizeof(cltConfiguracao));
    //Busca as configura��es do coletor
    cfg_opt_t opts[] = {
                CFG_SIMPLE_STR ("snmpComunidade", &cltConf->snmpComunidade),
                CFG_SIMPLE_INT ("snmpPorta", &cltConf->snmpPorta),
                CFG_SIMPLE_STR ("bdHost", &cltConf->bdHost),
                CFG_SIMPLE_STR ("bdPorta", &cltConf->bdPorta),
                CFG_SIMPLE_STR ("bdUsuario", &cltConf->bdUsuario),
                CFG_SIMPLE_STR ("bdNome", &cltConf->bdNome),
                CFG_SIMPLE_STR ("bdPassword", &cltConf->bdPassword),
                CFG_SIMPLE_INT ("cltTempoDeCaptura", &cltConf->cltTempoDeCaptura),
                CFG_SIMPLE_INT ("cltExibeNoticia", &cltConf->cltExibeNoticia),
                CFG_STR_LIST   ("cltIPsParaCaptura", NULL, CFGF_NONE),
                CFG_END()
                };
    utlLeConfiguracao(CLT_ARQUIVO_CONFIGURACAO, opts);

    UTL_EXIBE_NOTICIA = cltConf->cltExibeNoticia;
    utlListaConfiguracao *cltIPs, *cltIPsInicio;
    cltIPs = (utlListaConfiguracao*) malloc(sizeof(utlListaConfiguracao));
    utlLeListaConfiguracao(CLT_ARQUIVO_CONFIGURACAO, opts, "cltIPsParaCaptura", cltIPs);

    utlDebug("Iniciando coletor.", UTL_NOTICIA);

    //percore os ips a serem monitorados
    cltIPsInicio = cltIPs;
    while (1)
    {
        int tempoEmSegundos;
        utlTempoEmSegundos(&tempoEmSegundos);

        while (cltIPs != (utlListaConfiguracao*) NULL)
        {
            strcpy(cltConf->snmpHost, cltIPs->valor);
            cltIPs = cltIPs->proximo;

            strcpy(cltConf->cltNomeDoHost, cltIPs->valor);
            cltIPs = cltIPs->proximo;

            cltColetaDados(cltConf);
        }
        cltIPs = cltIPsInicio;

        int tempoEmSegundos2;
        utlTempoEmSegundos(&tempoEmSegundos2);
        int tempoDiff = tempoEmSegundos2 - tempoEmSegundos;

        sleep(cltConf->cltTempoDeCaptura-tempoDiff);
    }

    utlRemoveListaConfiguracao(cltIPs);
    free(cltConf);

    return 0;
}

void cltColetaDados(void *conf)
{
    struct snmp_session sessao, *ss;
    char *snmpErro;

    cltConfiguracao *cltConf;
    cltConf = conf;

    utlDebug("Coletando dados de %s.", UTL_NOTICIA, cltConf->snmpHost);

    ss = snmpCriarSessao(&sessao, cltConf);
    if (ss == NULL)
    {
        snmp_error(&sessao, NULL, NULL, &snmpErro);
        utlDebug("Erro ao criar a sess�o snmp - %s\n", UTL_CUIDADO, snmpErro);
    }

    cltTabelaDeProcessos *cltTP;
    cltTP     = (cltTabelaDeProcessos*) malloc(sizeof(cltTabelaDeProcessos));


    if (cltBuscaTabelaDeProcessos(cltTP, ss))
    {
        cltTabelaDeProcessos *cltNovaTP;
        cltNovaTP = malloc(sizeof(cltTabelaDeProcessos));
        cltNovaEstruturaAgrupada(cltTP, cltNovaTP);


        //cltImprimeTabelaDeProcessos(cltTP, cltConf->cltNomeDoHost);
        //cltImprimeTabelaDeProcessos(cltNovaTP, cltConf->cltNomeDoHost);

        cltGravarTabelaDeProcessos(cltNovaTP, cltConf);
        cltRemoverTabelaDeProcessos(cltNovaTP);
    }
    cltRemoverTabelaDeProcessos(cltTP);


    cltTabelaDeTemperatura *cltTT;
    cltTT     = (cltTabelaDeTemperatura*) malloc(sizeof(cltTabelaDeTemperatura));
    if (cltBuscaTabelaDeTemperatura(cltTT, ss))
    {
        //cltImprimeTabelaDeTemperatura(cltTT, cltConf->cltNomeDoHost);
        cltGravarTabelaDeTemperatura(cltTT, cltConf);
    }
    cltRemoverTabelaDeTemperatura(cltTT);

    cltTabelaDeParticoes *cltTPa;
    cltTPa     = (cltTabelaDeParticoes*) malloc(sizeof(cltTabelaDeParticoes));
    if (cltBuscaTabelaDeParticoes(cltTPa, ss))
    {
        //cltImprimeTabelaDeParticoes(cltTPa, cltConf->cltNomeDoHost);
        cltGravarTabelaDeParticoes(cltTPa, cltConf);
    }
    cltRemoverTabelaDeParticoes(cltTPa);



    snmpFecharSessao(ss);
}
