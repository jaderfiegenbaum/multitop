/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/


int agtAtribuiListaDeProcessos()
{
    struct dirent* entrada;
    struct agtProcesso *teste;
    int term;
    DIR* dir;
    int pid;

    dir = opendir(PROC_DIR);
    if (!dir)
    {
        perror(PROC_DIR);
        return 0;
    }

    agtPonteiroParaInicio();
    while ((entrada = readdir(dir)) != NULL)
    {
        char *nome = entrada->d_name;
        pid = atoi(nome);
        if (pid > 0 )
        {
            term=1;
            while (term == 1)
            {
                teste = agtPegaProcessoAtual();
                term = 0;

                //N�o existe mais processo na lista. Assim, adiciona.
                if (qtde_de_processos == 0)
                {
                    agtAdicionaProcesso(pid);
                }
                else if (!agtExisteProximoProcesso() && teste->pid < pid)
                {
                    //printf("Adicionou novo no fim %d\n", pid);
                    agtAdicionaProcesso(pid);
                }
                else
                {
                    //Os processos batem: atualiza dados
                    if (teste->pid == pid)
                    {
                        agtAtualizaProcesso(pid);
                        agtProximoProcesso();
                        //printf("Atualiza processo %d\n", teste->pid);
                    }
                    else //Os processos n�o batem
                    {
                        //novo processos
                        if (teste->pid > pid)
                        {
                            //printf("Adiciona novo processo %d antes de %d\n", pid, teste->pid);
                            adicionaAntes(pid);
                            agtProximoProcesso();
                        }
                        else if (teste->pid < pid)//processo morreu
                        {
                            term = 1;
                            //printf("Remove o processo %d - checando %d\n", teste->pid, pid);
                            agtRemoveProcessoAtual();
                        }
                    }
                }
            }
        }
    }

    //Remove processo do final da lista que n�o est�o rodando no sistema
    //printf("�ltimo %d\n", pid);
    do
    {
        teste = agtPegaProcessoAtual();
        if (teste->pid > pid)
        {
            //printf("Rmove %d\n", teste->pid);
            agtRemoveProcessoAtual();
        }
    } while (agtProximoProcesso());

    closedir(dir);

    return 1;
}
