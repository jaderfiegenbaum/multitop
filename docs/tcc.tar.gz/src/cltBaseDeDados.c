/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/


PGconn *bdConectar(cltConfiguracao *cltConf)
{
    char bdParam[UTL_TAM_MAX_M] = "";
    PGconn *conexao = NULL;

    //Monta o parametro para conex�o
    if (cltConf->bdHost)
    {
        strcat(bdParam, " host=");
        strcat(bdParam, cltConf->bdHost);
    }
    if (cltConf->bdPorta)
    {
        strcat(bdParam, " port=");
        strcat(bdParam, cltConf->bdPorta);
    }
    if (cltConf->bdUsuario)
    {
        strcat(bdParam, " user=");
        strcat(bdParam, cltConf->bdUsuario);
    }
    if (cltConf->bdNome)
    {
        strcat(bdParam, " dbname=");
        strcat(bdParam, cltConf->bdNome);
    }
    if (cltConf->bdPassword)
    {
        strcat(bdParam, " password=");
        strcat(bdParam, cltConf->bdPassword);
    }
    conexao = PQconnectdb(bdParam);
    if(PQstatus(conexao) != CONNECTION_OK)
    {
        utlDebug("Falha na conex�o. %s", UTL_ERRO_FATAL, PQerrorMessage(conexao));
        PQfinish(conexao);
    }

    return conexao;
}

void bdExecutar(PGconn *conexao, char *sql)
{
    PGresult *resultado;

    resultado = PQexec(conexao, sql);

    switch(PQresultStatus(resultado))
    {
        case PGRES_EMPTY_QUERY:
            utlDebug("O sql est� vazio.", UTL_CUIDADO);
            break;
        case PGRES_FATAL_ERROR:
            utlDebug("Erro no sql %s", UTL_CUIDADO, PQresultErrorMessage(resultado));
            break;
        case PGRES_COMMAND_OK:
            break;
        default:
            utlDebug("Problema n�o identificado ao executar o sql.", UTL_CUIDADO);
            break;
    }

    if (resultado)
    {
        PQclear(resultado);
    }
}

void bdFechar(PGconn *conexao)
{
    if(conexao != NULL)
    {
        PQfinish(conexao);
    }
}
