/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/


bool cltBuscaTabelaDeTemperatura(cltTabelaDeTemperatura *cltTT, struct snmp_session *ss)
{
    int x = 1, acabou = 0, maisLinhas = 0;
    char buf[50];
    while(!acabou)
    {
        sprintf(buf, "TCC-MIB::tIDDaLinha.%d", x);
        if (!snmpGet(ss, buf, &cltTT->IDDaLinha, &maisLinhas))
        {
            cltTT->proximo = (cltTabelaDeTemperatura*) NULL;
            cltTT = (cltTabelaDeTemperatura*) NULL;
            return false;
        }

        if (maisLinhas == 0)
        {
            if (x == 1)
            {
                cltTT->proximo = (cltTabelaDeTemperatura*) NULL;
                return false;
            }
            acabou = 1;
            break;
        }

        if (x > 1)
        {
            cltTT->proximo = (cltTabelaDeTemperatura*) malloc(sizeof(cltTabelaDeTemperatura));
            cltTT = cltTT->proximo;
        }

        sprintf(buf, "TCC-MIB::tDataHoraDaColeta.%d", x);
        snmpGet(ss, buf, &cltTT->dataHoraDaColeta, &maisLinhas);

        sprintf(buf, "TCC-MIB::tTemperatura.%d", x);
        snmpGet(ss, buf, &cltTT->temperatura, &maisLinhas);

        cltTT->proximo = (cltTabelaDeTemperatura*) NULL;
        x++;
    }

    utlDebug("%d temperatura(s) adicinada(s) na lista.", UTL_NOTICIA, x-1);
    return true;
}

void cltImprimeTabelaDeTemperatura(cltTabelaDeTemperatura *cltTT, char *cltNomeDoHost)
{
    cltTabelaDeTemperatura *auxiliar;
    printf("Tabela de temperatura:\n");
    for (auxiliar = cltTT; auxiliar != (cltTabelaDeTemperatura*) NULL; auxiliar = auxiliar->proximo)
    {
        printf("%s %s %d\n", cltNomeDoHost,
                             auxiliar->dataHoraDaColeta,
                             auxiliar->temperatura);
    }
}

void cltGravarTabelaDeTemperatura(cltTabelaDeTemperatura *cltTT, cltConfiguracao * cltConf)
{
    cltTabelaDeTemperatura *auxiliar;
    char bufSql[UTL_TAM_MAX_G];
    int quantidade = 0;

    PGconn *con = bdConectar(cltConf);
    for (auxiliar = cltTT; auxiliar != (cltTabelaDeTemperatura*) NULL;  auxiliar = auxiliar->proximo)
    {
        sprintf(bufSql, "INSERT INTO temperaturas (nomeDoHost, datahoradacoleta, temperatura)"
                                       " VALUES ('%s', '%s', %d);",
                                                cltConf->cltNomeDoHost,
                                                auxiliar->dataHoraDaColeta,
                                                auxiliar->temperatura);

        bdExecutar(con, bufSql);
        quantidade++;
    }
    bdFechar(con);

    utlDebug("%d temperatura(s) gravada(s) na base.", UTL_NOTICIA, quantidade);
}

void cltRemoverTabelaDeTemperatura(cltTabelaDeTemperatura *cltTT)
{
    cltTabelaDeTemperatura *auxiliar = (cltTabelaDeTemperatura*) NULL;
    cltTabelaDeTemperatura *anterior = (cltTabelaDeTemperatura*) NULL;
    int quantidade = 0;

    for (auxiliar = cltTT; auxiliar != (cltTabelaDeTemperatura*) NULL;  )
    {
        anterior = auxiliar;
        auxiliar = auxiliar->proximo;
        anterior->proximo = (cltTabelaDeTemperatura*) NULL;
        free(anterior);
        quantidade++;
    }
    //free(auxiliar);

    utlDebug("%d temperatura(s) removida(s) da lista.", UTL_NOTICIA, quantidade);
}
