
/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/

struct snmp_session *snmpCriarSessao(struct snmp_session *sessao, cltConfiguracao *cltConf)
{
    utlDebug("Criando uma sess�o snmp.", UTL_NOTICIA);

    snmp_sess_init(sessao);
    sessao->version = SNMP_VERSION_2c;
    sessao->peername = cltConf->snmpHost;
    sessao->remote_port = cltConf->snmpPorta;
    sessao->community = (unsigned char *)cltConf->snmpComunidade;
    sessao->community_len = strlen(cltConf->snmpComunidade);

    return(snmp_open(sessao));
}

void snmpFecharSessao(struct snmp_session *sessao)
{
    if (sessao != NULL)
    {
        snmp_close(sessao);
    }
}

bool snmpGet(struct snmp_session *ss, char *objeto, void *resultado, int *maisLinhas)
{
    utlDebug("Caminhando pelo objeto '%s'.", UTL_NOTICIA, objeto);

    *maisLinhas = 0;

    struct snmp_pdu *pdu = NULL, *resposta = NULL;
    struct variable_list *vars;

    oid root[MAX_OID_LEN];
    size_t rootLen = MAX_OID_LEN;

    int terminou = 0;
    int status = 0;
    int valoresEncontrados = 0;


    char temp[UTL_TAM_MAX_P], buf[UTL_TAM_MAX_P]; int count;

    init_snmp("snmpGet");

    if (!snmp_parse_oid(objeto, root, &rootLen))
    {
        printf("Parse\n");
        return false;
    }

    pdu = snmp_pdu_create(SNMP_MSG_GET);
    snmp_add_null_var(pdu, root, rootLen);

    status = snmp_synch_response(ss, pdu, &resposta);
    if (status == STAT_SUCCESS)
    {
        if (resposta->errstat == SNMP_ERR_NOERROR)
        {
            for(vars = resposta->variables; vars; vars = vars->next_variable)
            {
                valoresEncontrados++;
                snprint_variable(buf,sizeof(buf),vars->name,vars->name_length,vars);
                strcat(buf,"\n");

                if (vars->type == ASN_INTEGER)
                {
                    int *res = resultado;
                    *res = *(vars->val.integer);

                    *maisLinhas = 1;
                }
                else if (vars->type == ASN_OCTET_STR)
                {
                    char *sp = (char *) malloc(1 + vars->val_len);
                    memcpy(sp, vars->val.string, vars->val_len);
                    sp[vars->val_len] = '\0';
                    sprintf(resultado, "%s", sp);
                    free(sp);
                    *maisLinhas = 1;
                }
            }
        }
        else
        {
            //Trata os erros de resposta
            if (resposta->errstat == SNMP_ERR_NOSUCHNAME)
            {
                printf("    END MIB\n");
            }
            else
            {
                utlDebug("Erro no pacote: %s", UTL_CUIDADO, snmp_errstring(resposta->errstat));
                if (resposta->errstat == SNMP_ERR_NOSUCHNAME)
                {
                    sprintf(temp,"The request for this object identifier failed: ");
                    for(count = 1, vars = resposta->variables; vars && count != resposta->errindex; vars = vars->next_variable, count++)
                    {
                        if (vars)
                        {
                            snprint_objid(buf,sizeof(buf),vars->name,vars->name_length);
                            strcat(temp,buf);
                        }
                    }
                    printf("E: %s\n", temp);
                }
            }
        }

    }
    else if (status == STAT_TIMEOUT)
    {
        utlDebug("Tempo esgotou enquanto conectava em '%s'", UTL_CUIDADO, ss->peername);
        snmp_close(ss);
        return false;
    }
    else
    {    /* status == STAT_ERROR */
        snmp_sess_perror("snmpGet", ss);
        terminou = 1;
    }
    if (resposta)
    {
        snmp_free_pdu(resposta);
    }

    return true;
}
