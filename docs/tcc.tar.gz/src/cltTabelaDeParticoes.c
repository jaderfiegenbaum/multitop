/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/


bool cltBuscaTabelaDeParticoes(cltTabelaDeParticoes *cltTPa, struct snmp_session *ss)
{
    int x = 1, acabou = 0, maisLinhas = 0;
    char buf[50];
    char resultadoTmp[50];
    while(!acabou)
    {
        sprintf(buf, "TCC-MIB::aIDDaLinha.%d", x);
        if (!snmpGet(ss, buf, &cltTPa->IDDaLinha, &maisLinhas))
        {
            cltTPa->proximo = (cltTabelaDeParticoes*) NULL;
            cltTPa = (cltTabelaDeParticoes*) NULL;
            return false;
        }

        if (maisLinhas == 0)
        {
            if (x == 1)
            {
                cltTPa->proximo = (cltTabelaDeParticoes*) NULL;
                return false;
            }
            acabou = 1;
            break;
        }

        if (x > 1)
        {
            cltTPa->proximo = (cltTabelaDeParticoes*) malloc(sizeof(cltTabelaDeParticoes));
            cltTPa = cltTPa->proximo;
        }

        sprintf(buf, "TCC-MIB::aDataHoraDaColeta.%d", x);
        snmpGet(ss, buf, &cltTPa->dataHoraDaColeta, &maisLinhas);

        sprintf(buf, "TCC-MIB::aNome.%d", x);
        snmpGet(ss, buf, &cltTPa->nome, &maisLinhas);

        sprintf(buf, "TCC-MIB::aPontoDeMontagem.%d", x);
        snmpGet(ss, buf, &cltTPa->pontoDeMontagem, &maisLinhas);

        sprintf(buf, "TCC-MIB::aTotalEmKb.%d", x);
        snmpGet(ss, buf, &resultadoTmp, &maisLinhas);
        cltTPa->totalEmKb = atof(resultadoTmp);


        sprintf(buf, "TCC-MIB::aUsadoEmKb.%d", x);
        snmpGet(ss, buf, &resultadoTmp, &maisLinhas);
        cltTPa->usadoEmKb = atof(resultadoTmp);

        cltTPa->proximo = (cltTabelaDeParticoes*) NULL;
        x++;
    }

    utlDebug("%d partic�o adicinada na lista.", UTL_NOTICIA, x-1);
    return true;
}

void cltImprimeTabelaDeParticoes(cltTabelaDeParticoes *cltTPa, char *cltNomeDoHost)
{
    cltTabelaDeParticoes *auxiliar;
    printf("Tabela de partic�es:\n");
    for (auxiliar = cltTPa; auxiliar != (cltTabelaDeParticoes*) NULL; auxiliar = auxiliar->proximo)
    {
        printf("%s %s %s %s %f %f\n", cltNomeDoHost,
                             auxiliar->dataHoraDaColeta,
                             auxiliar->nome,
                             auxiliar->pontoDeMontagem,
                             auxiliar->totalEmKb,
                             auxiliar->usadoEmKb);
    }
}

void cltGravarTabelaDeParticoes(cltTabelaDeParticoes *cltTPa, cltConfiguracao * cltConf)
{
    cltTabelaDeParticoes *auxiliar;
    char bufSql[UTL_TAM_MAX_G];
    int quantidade = 0;

    PGconn *con = bdConectar(cltConf);
    for (auxiliar = cltTPa; auxiliar != (cltTabelaDeParticoes*) NULL;  auxiliar = auxiliar->proximo)
    {
        sprintf(bufSql, "INSERT INTO particoes (nomeDoHost, datahoradacoleta, nome, pontoDeMontagem, totalEmKb, usadoEmKb)"
                                       " VALUES ('%s', '%s', '%s', '%s', %f, %f);",
                                                cltConf->cltNomeDoHost,
                                                auxiliar->dataHoraDaColeta,
                                                auxiliar->nome,
                                                auxiliar->pontoDeMontagem,
                                                auxiliar->totalEmKb,
                                                auxiliar->usadoEmKb);

        bdExecutar(con, bufSql);
        quantidade++;
    }
    bdFechar(con);

    utlDebug("%d partic�o(�es) gravada(s) na base.", UTL_NOTICIA, quantidade);
}

void cltRemoverTabelaDeParticoes(cltTabelaDeParticoes *cltTPa)
{
    cltTabelaDeParticoes *auxiliar = (cltTabelaDeParticoes*) NULL;
    cltTabelaDeParticoes *anterior = (cltTabelaDeParticoes*) NULL;
    int quantidade = 0;
    for (auxiliar = cltTPa; auxiliar != (cltTabelaDeParticoes*) NULL;  )
    {
        anterior = auxiliar;
        auxiliar = auxiliar->proximo;
        anterior->proximo = (cltTabelaDeParticoes*) NULL;
        free(anterior);
        quantidade++;
    }
    //free(auxiliar);

    utlDebug("%d partic�o(�es) removida(s) da lista.", UTL_NOTICIA, quantidade);
}
