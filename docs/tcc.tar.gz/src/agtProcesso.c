
/**
 *
 * @author Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @version $Id$
 *
 * \b Maintainers: \n
 * Jamiel Spezia [jamiel@jamiel.eng.br]
 *
 * @since
 * Created on 01/06/2007
 *
 * \b CopyLeft: \n
 * CopyLeft (L) 2007 Jamiel Spezia \n
 *
 * \b License: \n
 * Licensed under GPL (for further details read the COPYING file or http://www.gnu.org/copyleft/gpl.html )
 *
 **/

/* Fun��es para controle da estrutura */
void agtPonteiroParaInicio()
{
    processo_atual = processo_inicial;
}

struct agtProcesso *agtPegaProcessoAtual()
{
    return processo_atual;
}

int agtExisteProximoProcesso()
{
    if (processo_atual->prox_processo != (struct agtProcesso*) NULL)
    {
        return 1;
    }
    return 0;
}

int agtProximoProcesso()
{
    if (agtExisteProximoProcesso())
    {
        processo_atual = processo_atual->prox_processo;
        return 1;
    }
    return 0;
}

int agtLeProc(int pid)
{
    FILE* status;
    char caminho[UTL_TAM_MAX_P + 1];

    long int luNull;
    int dNull;
    char cNull;

    snprintf(caminho, UTL_TAM_MAX_P, "%s/%d/stat", PROC_DIR, pid);
    status = fopen(caminho, "r");
    if (status)
    {

        fscanf(status, "%d %s %c %d "
                       "%d %d %d %d "
                       "%lu %lu %lu %lu "
                       "%lu %lu %lu",
                        &processo_atual->pid, &processo_atual->comm, &cNull, &dNull,
                        &dNull, &dNull, &dNull, &dNull,
                        &luNull, &luNull, &luNull, &luNull,
                        &luNull, &processo_atual->utime, &processo_atual->stime);


        utlUsuarioDoProcesso(processo_atual->pid, processo_atual->usuario);

        float tempoTotal = (float) processo_atual->utime + processo_atual->stime;
        processo_atual->jiffies = tempoTotal - processo_atual->ultimosJiffies;
        processo_atual->ultimosJiffies = tempoTotal;
    }
    fclose(status);

    //Mem�ria
    snprintf(caminho, UTL_TAM_MAX_P, "%s/%d/statm", PROC_DIR, pid);
    status = fopen(caminho, "r");
    if (status)
    {
        fscanf(status, "%d %d %d %d %d %d %d",
                &processo_atual->size,
                &processo_atual->resident,
                &processo_atual->share,
                &processo_atual->text,
                &processo_atual->lib,
                &processo_atual->data,
                &processo_atual->dt);

        processo_atual->resident = processo_atual->resident * PAGE_SIZE;
    }
    fclose(status);

    return 1;
}

int agtAdicionaProcesso(int pid)
{
    utlDebug("Adicionando novo processo.", UTL_NOTICIA);

    struct agtProcesso *novo_processo;
    novo_processo = (struct agtProcesso*) malloc(sizeof(struct agtProcesso));

    /* Verificar se � o primeiro processo para manter o controle de in�cio da lista */
    if (processo_inicial == (struct agtProcesso*) NULL)
    {
        utlDebug("Primeiro processo.", UTL_NOTICIA);
        novo_processo->prox_processo = (struct agtProcesso*) NULL;
        processo_inicial = processo_atual = novo_processo;
    }
    else
    {
        /* Coloca o ponteiro atual com sendo o �ltimo da lista */
        while (agtExisteProximoProcesso())
        {
            processo_atual = processo_atual->prox_processo;
        }

        novo_processo->processo_anterior = processo_atual;
        processo_atual->prox_processo = novo_processo;

        //Atribui ao processo atual o novo processo
        processo_atual = novo_processo;
        processo_atual->prox_processo = (struct agtProcesso*) NULL;
    }

    qtde_de_processos++;
    //processo_atual->pid = pid;
    agtLeProc(pid);

    return 1;
}

int adicionaAntes(pid)
{
    utlDebug("Adicionando novo processo antes do atual.", UTL_NOTICIA);

    struct agtProcesso *novo_processo;
    novo_processo = (struct agtProcesso*) malloc(sizeof(struct agtProcesso));

    novo_processo->processo_anterior = processo_atual->processo_anterior;
    novo_processo->prox_processo = processo_atual;

    processo_atual->processo_anterior->prox_processo = novo_processo;

    processo_atual->processo_anterior = novo_processo;


    processo_atual = novo_processo;

    qtde_de_processos++;
    agtLeProc(pid);

    return 1;
}

int agtAtualizaProcesso(int pid)
{
    agtLeProc(pid);

    return 1;
}

int agtRemoveProcessoAtual()
{
    utlDebug("Removendo processo.", UTL_NOTICIA);

    struct agtProcesso *processo_auxiliar = (struct agtProcesso*) NULL;

    if (processo_atual->processo_anterior != (struct agtProcesso*) NULL)
    {
    //printf("Anterior: %d\n", processo_atual->processo_anterior->pid);
        processo_atual->processo_anterior->prox_processo = processo_atual->prox_processo;
        processo_auxiliar = processo_atual->processo_anterior;
    }

    if (processo_atual->prox_processo != (struct agtProcesso*) NULL)
    {
    //printf("Proximo: %d\n", processo_atual->prox_processo->pid);
        processo_atual->prox_processo->processo_anterior = processo_atual->processo_anterior;
        processo_auxiliar = processo_atual->prox_processo;
    }
    free(processo_atual);
    processo_atual = processo_auxiliar;
    processo_auxiliar = (struct agtProcesso*) NULL;
    free(processo_auxiliar);
    qtde_de_processos--;

    return 1;
}
